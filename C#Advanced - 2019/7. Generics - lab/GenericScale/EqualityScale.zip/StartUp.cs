﻿using System;

namespace GenericScale
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var currentScale = new EqualityScale<string>("15", "15");
            string result = currentScale.AreEqual();
            Console.WriteLine(result);

            var secondScale = new EqualityScale<string>("Maria", "Gergana");
            string secondResult = secondScale.AreEqual();
            Console.WriteLine(secondResult);

            var thirdScale = new EqualityScale<int>(25, 25);
            string thirdResult = thirdScale.AreEqual();
            Console.WriteLine(thirdResult);

        }
    }
}
