﻿using System;
using System.Collections.Generic;

namespace GenericCountMethod
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int countOfLine = int.Parse(Console.ReadLine());

            Box<string> box = new Box<string>();

            for (int i = 0; i < countOfLine; i++)
            {
                string line = Console.ReadLine();
                box.Add(line);
            }

            string value = Console.ReadLine();

            int count = GetCountOgGreaterElement(box.Data, value);
            Console.WriteLine(count);

        }

        public static int GetCountOgGreaterElement<T>(List<T> listOfData, T value)
            where T : IComparable
        {
            int count = 0;

            foreach (var item in listOfData) //-1 < ; 0 =; 1 >
            {
                if(item.CompareTo(value) > 0)
                {
                    count++;
                }
            }

            return count;
        }
    }
}
