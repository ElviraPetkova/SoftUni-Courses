﻿
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> listOfPeople;

        public List<Person> ListOfPeople
        {
            get { return this.listOfPeople; }

            set
            {
                this.listOfPeople = new List<Person>();
            }
        }

        public void AddMember(Person person)
        {
            listOfPeople.Add(person);
        }

        public Person GetOldestMember(List<Person> list)
        {
            int old = list.Max(x=>x.Age);
            Person oldestPerson = list
                .FirstOrDefault(x => x.Age == old);

            return oldestPerson;
        }
    }
}
