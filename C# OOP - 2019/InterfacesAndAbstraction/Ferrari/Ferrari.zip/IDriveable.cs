﻿namespace Ferrari
{
    public interface IDriveable
    {
        string UseBrakes();

        string PushGas();
    }
}
