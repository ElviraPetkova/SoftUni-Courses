﻿using System;
using System.Text;

namespace Shapes
{
    public class Rectangle : IDrawable
    {
        public Rectangle(int width, int height)
        {
            this.Width = width;
            this.Height = height;
        }

        public int Width { get; private set; }

        public int Height { get; private set; }

        public void Draw()
        {
            //StringBuilder stringBuilder = new StringBuilder();

            DrawLine(this.Width, '*', '*');//, stringBuilder);
            for (int i = 1; i < this.Height - 1; ++i)
            {
                DrawLine(this.Width, '*', ' '); //, stringBuilder);
            }
            DrawLine(this.Width, '*', '*');//, stringBuilder);

            //return stringBuilder.ToString();
        }

        private void DrawLine(int width, char end, char mid)//, StringBuilder stringBuild)
        {
            Console.Write(end);
            for (int i = 1; i < width - 1; ++i)
            {
                Console.Write(mid);
            }
            Console.WriteLine(end);
        }
    }
}
