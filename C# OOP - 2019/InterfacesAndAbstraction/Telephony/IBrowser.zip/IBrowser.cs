﻿namespace Telephony
{
    public interface IBrowser
    {
        string Browse(string url);
    }
}
