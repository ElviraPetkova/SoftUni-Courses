﻿namespace BorderControl
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Startup
    {
        static void Main(string[] args)
        {
            //List<IIdentifiable> all = new List<IIdentifiable>();
            List<IBirthable> all = new List<IBirthable>();

            string input;

            while ((input = Console.ReadLine()) != "End")
            {
                string[] line = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (line[0] == "Citizen")
                {
                    string name = line[1];
                    int age = int.Parse(line[2]);
                    string id = line[3];
                    string birthade = line[4];

                    IBirthable citzen = new Citizen(name, age, id, birthade);

                    all.Add(citzen);
                }
                else if (line[0] == "Pet")
                {
                    string name = line[1];
                    string birthdate = line[2];

                    IBirthable pet = new Pet(name, birthdate);

                    all.Add(pet);
                }
            }

            string year = Console.ReadLine();

            all.Where(y => y.Birthdate.Year == int.Parse(year))
                 .Select(x => x.Birthdate)
                 .ToList()
                 .ForEach(dt => Console.WriteLine($"{dt:dd/mm/yyyy}"));

            

            //var selectedId = all
            //    .Where(i => i.Id.EndsWith(lastDigitOfId))
            //    .Select(x => x.Id)
            //    .ToList();

            //Console.WriteLine(string.Join(Environment.NewLine, selectedId));
        }

        
    }
}
