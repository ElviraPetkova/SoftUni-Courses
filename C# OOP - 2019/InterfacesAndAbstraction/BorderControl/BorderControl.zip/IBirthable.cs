﻿namespace BorderControl
{
    using System;

    public interface IBirthable
    {
        DateTime  Birthdate { get; }
    }
}
