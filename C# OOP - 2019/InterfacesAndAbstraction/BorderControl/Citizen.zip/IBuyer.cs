﻿namespace BorderControl
{
    public interface IBuyer
    {
        int Food { get; }
        void BuyFood();
    }
}
