﻿namespace MilitaryElite.Interfaces
{
    public interface IPrivate
    {
        decimal Salary { get; }
    }
}
