﻿namespace MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}
