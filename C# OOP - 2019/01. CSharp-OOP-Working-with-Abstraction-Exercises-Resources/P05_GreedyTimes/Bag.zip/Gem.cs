﻿namespace P05_GreedyTimes
{
    public class Gem : Item
    {

        public Gem(string key, long value)
        {
            this.Key = key;
            this.Value = value;
        }
    }
}
