﻿namespace Restaurant
{
    using BeverageClases;
    using BeverageClases.HotBeverage;
    using BeverageClases.ColdBeverage;
    using FoodClases;
    using FoodClases.Starter;
    using FoodClases.MainDish;
    using FoodClases.Dessert;

    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}