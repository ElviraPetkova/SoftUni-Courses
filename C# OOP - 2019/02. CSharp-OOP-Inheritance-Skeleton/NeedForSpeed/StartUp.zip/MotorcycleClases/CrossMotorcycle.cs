﻿namespace NeedForSpeed.MotorcycleClases
{
    public class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(int horsePower, double fuel)
            : base(horsePower, fuel)
        {
        }
    }
}
