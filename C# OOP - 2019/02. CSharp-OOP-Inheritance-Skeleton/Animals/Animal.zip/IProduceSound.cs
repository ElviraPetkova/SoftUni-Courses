﻿namespace Animals
{
    interface IProduceSound
    {
        string ProduceSound();
    }
}
