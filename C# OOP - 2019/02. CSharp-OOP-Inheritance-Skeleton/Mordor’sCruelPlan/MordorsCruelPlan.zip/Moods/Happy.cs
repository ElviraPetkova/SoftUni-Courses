﻿namespace MordorsCruelPlan.Moods
{
    public class Happy : Mood
    {
        public override int From => 1;
        public override int To => 15;
    }

}
