﻿namespace MordorsCruelPlan.Moods
{
    public class Mood
    {
        public virtual int From { get; }

        public virtual int To { get; }
    }
}
