﻿namespace MordorsCruelPlan.Foods
{
    public class Cram : Food
    {
        public override int Happiness => 2;
    }
}
