﻿namespace MordorsCruelPlan.Foods
{
    public class Lembas : Food
    {
        public override int Happiness => 3;
    }
}
