﻿namespace MordorsCruelPlan.Foods
{
    public class Melon : Food
    {
        public override int Happiness => 1;
    }
}
