﻿namespace MordorsCruelPlan.Foods
{
    public class HoneyCake : Food
    {
        public override int Happiness => 5;
    }
}
