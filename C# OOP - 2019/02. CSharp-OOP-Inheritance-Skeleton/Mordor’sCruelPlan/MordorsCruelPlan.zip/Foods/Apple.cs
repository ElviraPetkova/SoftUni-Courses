﻿namespace MordorsCruelPlan.Foods
{
    public class Apple : Food
    {
        public override int Happiness => 1;
    }
}
