﻿namespace Vehicles
{
    using Models;

    using System;

    public class Startup
    {
        static void Main(string[] args)
        {
            string[] carInformation = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            double carQuantity = double.Parse(carInformation[1]);
            double carLitersPerKm = double.Parse(carInformation[2]);
            double carTankCapacity = double.Parse(carInformation[3]);

            string[] truckInformation = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            double truckQuantity = double.Parse(truckInformation[1]);
            double truckLitersPerKm = double.Parse(truckInformation[2]);
            double truckTankCapacity = double.Parse(truckInformation[3]);

            string[] busInformation = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            double busQuantity = double.Parse(busInformation[1]);
            double busLitersPerKm = double.Parse(busInformation[2]);
            double busTankCapacity = double.Parse(busInformation[3]);

            Car car = new Car(carQuantity, carLitersPerKm, carTankCapacity);
            Truck truck = new Truck(truckQuantity, truckLitersPerKm, truckTankCapacity);
            Bus bus = new Bus(busQuantity, busLitersPerKm, busTankCapacity);

            int countOfCommands = int.Parse(Console.ReadLine());

            for (int i = 0; i < countOfCommands; i++)
            {
                string[] input = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string command = input[0];
                string typeVechicle = input[1];
                double litersOrDistance = double.Parse(input[2]);

                if (command == "Drive")
                {
                    switch (typeVechicle)
                    {
                        case "Car": Console.WriteLine(car.Drive(litersOrDistance)); break;
                        case "Truck": Console.WriteLine(truck.Drive(litersOrDistance)); break;
                        case "Bus": Console.WriteLine(bus.Drive(litersOrDistance)); break;
                    }
                }
                else if (command == "DriveEmpty")
                {
                    Console.WriteLine(bus.DriveEmpty(litersOrDistance));
                }
                else if (command == "Refuel")
                {
                    try
                    {
                        switch (typeVechicle)
                        {
                            case "Car": car.Refuel(litersOrDistance); break;
                            case "Truck": truck.Refuel(litersOrDistance); break;
                            case "Bus": truck.Refuel(litersOrDistance); break;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    
                }
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
            Console.WriteLine(bus);
            
        }
    }
}
